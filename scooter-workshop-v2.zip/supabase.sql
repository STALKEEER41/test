-- Supabase SQL Editor -> New query -> вставить весь файл -> Run
create extension if not exists pgcrypto;
create table if not exists public.scooters (
 id uuid primary key default gen_random_uuid(), city text not null check(city in ('Арсеньев','Дальнегорск','Лесозаводск')),
 number text not null, model text not null default 'Ninebot Max G30',
 status text not null default 'На складе' check(status in ('На складе','В прокате','Ремонт','Готов к прокату','Ожидает запчасти','Зимовка')),
 needs_charge boolean not null default false, notes text not null default '',
 winter_notes text not null default '', winter_stage text not null default 'Сейчас',
 winter_checks jsonb not null default '{}'::jsonb, spring_tasks text not null default '',
 created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
 unique(city,number)
);
create table if not exists public.repair_history (
 id uuid primary key default gen_random_uuid(), scooter_id uuid not null references public.scooters(id) on delete cascade,
 city text not null, scooter_number text not null, repair_date date not null default current_date,
 description text not null, parts_used text not null default '', cost numeric(10,2), employee text not null default '',
 created_at timestamptz not null default now()
);
create table if not exists public.parts (
 id uuid primary key default gen_random_uuid(), city text not null check(city in ('Арсеньев','Дальнегорск','Лесозаводск')),
 scooter_id uuid references public.scooters(id) on delete set null, scooter_number text not null default '',
 name text not null, quantity integer not null default 1 check(quantity>0),
 status text not null default 'Нужно купить' check(status in ('Нужно купить','Заказано','Получено','Установлено')),
 notes text not null default '', created_at timestamptz not null default now()
);
create index if not exists scooters_city_number_idx on public.scooters(city,number);
create index if not exists repair_city_date_idx on public.repair_history(city,repair_date desc);
create index if not exists parts_city_status_idx on public.parts(city,status);
alter table public.scooters enable row level security;
alter table public.repair_history enable row level security;
alter table public.parts enable row level security;
do $$ declare t text; begin
 foreach t in array array['scooters','repair_history','parts'] loop
  execute format('drop policy if exists "auth all %s" on public.%I',t,t);
  execute format('create policy "auth all %s" on public.%I for all to authenticated using (true) with check (true)',t,t);
 end loop;
end $$;
-- Realtime для синхронизации. Если таблица уже включена, блок не упадёт.
do $$ begin alter publication supabase_realtime add table public.scooters; exception when duplicate_object then null; when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.repair_history; exception when duplicate_object then null; when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.parts; exception when duplicate_object then null; when others then null; end $$;
